﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class frmgridview
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' SqlConnection string
        Dim cn As New SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString)
        ' SqlCommand
        Dim cmd As New SqlCommand("select * from studentinfo", cn)
        ' SqlDataAdapter
        Dim da As New SqlDataAdapter(cmd)
        ' dataset
        Dim ds As New DataSet
        da.Fill(ds)
        ' show data in data grid view
        GridView2.DataSource = ds.Tables(0)
        GridView2.DataBind()

    End Sub

    Protected Sub GridView2_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GridView2.SelectedIndexChanged

    End Sub
End Class
