﻿
Partial Class PostbankDemo
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            DropDownList1.Items.Add("BCA")
            DropDownList1.Items.Add("BBA")
            DropDownList1.Items.Add("BCOM")
        Else
            MsgBox("Does not click this buttton")
        End If
    End Sub
End Class
