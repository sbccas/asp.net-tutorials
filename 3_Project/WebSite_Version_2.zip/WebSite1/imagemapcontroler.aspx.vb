﻿
Partial Class imagemapcontroler
    Inherits System.Web.UI.Page

    Protected Sub ImageMap1_Click(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.ImageMapEventArgs) Handles ImageMap1.Click

    End Sub
End Class
