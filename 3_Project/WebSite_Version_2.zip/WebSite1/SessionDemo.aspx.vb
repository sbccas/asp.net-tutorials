﻿
Partial Class SessionDemo
    Inherits System.Web.UI.Page

    Protected Sub btncreatesession_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btncreatesession.Click
        Session("sname") = TextBox1.Text
        Session("ltime") = System.DateTime.Now.ToString
        Session.Add("Smbile", 7485961230)
        Session.Timeout = 1
        Label2.Text = "Session Created Successfully at" & System.DateTime.Now.ToString
    End Sub
    Protected Sub btnreadsession_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnreadsession.Click
        Label2.Text = "Your Session Data & Propartiles <br>"
        Label2.Text += "Session id:" & Session.SessionID & "<br>"
        Label2.Text += "Session Count:" & Session.Count & "<br>"
        Label2.Text += "Is New Session:" & Session.IsNewSession & "<br>"
        Label2.Text += "Is Cookieless:" & Session.IsCookieless & "<br>"
        Label2.Text += "Cookie Mode:" & Session.CookieMode.ToString & "<br>"
        Label2.Text += "TimeOut:" & Session.Timeout & "<br>"
        Label2.Text += "session Mode:" & Session.Mode.ToString & "<br>"

    End Sub
    Protected Sub btnlogout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnlogout.Click
        Session.Abandon()
    End Sub

    Protected Sub btnreaddata_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnreaddata.Click
        For i As Integer = 0 To Session.Count - 1
            Label2.Text += "Session data :" & i & "=" & Session(i).ToString & "<br>"
        Next
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label2.Text = "OnlineUsers = " + Application("OnlineUsers").ToString
    End Sub
End Class
