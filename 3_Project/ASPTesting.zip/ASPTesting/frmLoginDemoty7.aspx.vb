﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub btnLogin_Click(sender As Object, e As System.EventArgs) Handles btnLogin.Click
        Dim cn As New SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings("ty7").ConnectionString)
        Dim cmd As New SqlCommand("select * from studinfo where username='" & txtUsername.Text & "' and password='" & txtPassword.Text & "'", cn)
        Dim da As New SqlDataAdapter(cmd)
        Dim ds As New DataSet
        da.Fill(ds)
        If ds.Tables(0).Rows.Count > 0 Then
            Session("sid") = ds.Tables(0).Rows(0).Item(0).ToString
            Response.Redirect("frmUpdateProfileDemoTY7.aspx")

        Else
            Label1.Text = "USERNAME OF PASSWORD INCORRECT"
        End If

    End Sub
End Class
