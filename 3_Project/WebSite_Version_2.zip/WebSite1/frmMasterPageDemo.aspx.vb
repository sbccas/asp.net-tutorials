﻿
Partial Class frmMasterPageDemo
    Inherits System.Web.UI.Page

End Class
