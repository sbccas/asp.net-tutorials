﻿
Partial Class frmAdvanceGridViewDemoty7
    Inherits System.Web.UI.Page

End Class
