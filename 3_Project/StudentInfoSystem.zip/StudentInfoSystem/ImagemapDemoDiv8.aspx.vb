﻿
Partial Class ImagemapDemoDiv8
    Inherits System.Web.UI.Page

End Class
