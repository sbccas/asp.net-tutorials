﻿
Partial Class advanceGridView
    Inherits System.Web.UI.Page

End Class
