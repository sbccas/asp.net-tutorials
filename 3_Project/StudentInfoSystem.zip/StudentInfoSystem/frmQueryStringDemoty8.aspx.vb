﻿
Partial Class frmQueryStringDemoty8
    Inherits System.Web.UI.Page

End Class
