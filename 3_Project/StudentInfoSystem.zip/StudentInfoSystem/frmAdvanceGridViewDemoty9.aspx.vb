﻿
Partial Class frmAdvanceGridViewDemoty9
    Inherits System.Web.UI.Page

End Class
