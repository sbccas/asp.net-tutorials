﻿
Partial Class frmFileUploadDemo
    Inherits System.Web.UI.Page

    Protected Sub btnUpload_Click(sender As Object, e As System.EventArgs) Handles btnUpload.Click
        Dim strpath As String = Server.MapPath("uploads")
        If Page.IsPostBack Then
            If FileUpload1.HasFile Then
                FileUpload1.SaveAs(strpath & "\" & FileUpload1.FileName)
                lblstatus.Text = "File Upload Success at " & strpath & "\" & FileUpload1.FileName
            Else
                lblstatus.Text = "PLEASE SELECT A FILE"
            End If
        Else

        End If
        

       
    End Sub

    Protected Sub btnUpload2_Click(sender As Object, e As System.EventArgs) Handles btnUpload2.Click
        Dim strpath2 As String = Request.PhysicalApplicationPath
        lblstatus.Text = "Request. Applicationpath = " & strpath2
    End Sub
End Class
