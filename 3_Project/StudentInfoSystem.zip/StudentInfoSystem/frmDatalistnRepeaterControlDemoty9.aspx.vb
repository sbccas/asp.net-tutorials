﻿
Partial Class frmDatalistnRepeaterControlDemoty9
    Inherits System.Web.UI.Page

End Class
