﻿
Partial Class frmAdvanceGridViewDemoty8
    Inherits System.Web.UI.Page

End Class
