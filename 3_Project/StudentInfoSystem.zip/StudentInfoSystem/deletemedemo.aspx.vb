﻿
Partial Class deletemedemo
    Inherits System.Web.UI.Page

End Class
