﻿
Partial Class webcontrol1
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim str As String = "You selected"

        If ckbicecream.Checked = True Then
            str += ckbicecream.Text & ", "
        End If

        If ckbcolddrink.Checked = True Then
            str += ckbcolddrink.Text & ", "
        End If

        If ckbdsoda.Checked = True Then
            str += ckbdsoda.Text & ", "
        End If

        If ckbjuice.Checked = True Then
            str += ckbjuice.Text & ", "
        End If

        If ckbtea.Checked = True Then
            str += ckbtea.Text & ", "
        End If

        MsgBox(str)

    End Sub
End Class
