﻿
Partial Class listcontrolledemo
    Inherits System.Web.UI.Page

    Protected Sub btncheck_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btncheck.Click
        'Label1.Text = ListBox1.SelectedItem.ToString
        'Label1.Text += ListBox1.SelectedValue.ToString()
        'Dim i As Integer = 0
        ListBox2.Items.Clear()
        Dim inda() As Integer = ListBox1.GetSelectedIndices
        For Each i As Integer In inda
            ListBox2.Items.Add(ListBox1.Items(i).ToString)
        Next
        Label2.Text = "Listbox 1:" & ListBox1.Items.Count
        Label2.Text = "<br>listbox 2:" & ListBox2.Items.Count
    End Sub

    Protected Sub ListBox1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        'Label1.Text = ListBox1.SelectedItem.ToString
        'Label1.Text += ListBox1.SelectedValue.ToString()
    End Sub

    Protected Sub btncheck0_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btncheck0.Click
        'ListBox2.Items.Add(ListBox1.SelectedItem.ToString)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            ListBox1.Items.Add("BCA")
            ListBox1.Items.Add("BBA")
            ListBox1.Items.Add("BCOM")
            ListBox1.Items.Add("BSC")
            ListBox1.Items.Add("BSC DATASCINSE")
            ListBox1.Items.Add("MCOM")
            ListBox1.Items.Add("MSC")
        End If
        Label2.Text = "Listbox 1:" & ListBox1.Items.Count
        Label2.Text = "<br>listbox 2:" & ListBox2.Items.Count
    End Sub
End Class
