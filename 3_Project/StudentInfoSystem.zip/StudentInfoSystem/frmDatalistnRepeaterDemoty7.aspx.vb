﻿
Partial Class frmDatalistnRepeaterDemoty7
    Inherits System.Web.UI.Page

End Class
