﻿
Partial Class frmUpdateProfileDemoTY7
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            If Session("sid") = "" Then
                Response.Redirect("frmLoginDemoty7.aspx")
            Else
                'THIS CODE IS FOR DIPLAY LOGGED IN STUDENT INFO
                Dim cn As New SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings("ty7").ConnectionString)
                Dim cmd As New SqlCommand("select * from studinfo where sid=" & Session("sid") & ";", cn)
                Dim da As New SqlDataAdapter(cmd)
                Dim ds As New DataSet
                da.Fill(ds)
                txtStudentName.Text = ds.Tables(0).Rows(0).Item(1).ToString
                txtUsername.Text = ds.Tables(0).Rows(0).Item(5).ToString
                txtEmail.Text = ds.Tables(0).Rows(0).Item(3).ToString
                txtMobile.Text = ds.Tables(0).Rows(0).Item(2).ToString
                txtCity.Text = ds.Tables(0).Rows(0).Item(4).ToString

            End If


        Else


        End If
    End Sub
End Class
